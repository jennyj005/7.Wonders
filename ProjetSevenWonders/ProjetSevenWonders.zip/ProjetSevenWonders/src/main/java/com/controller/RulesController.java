package com.controller;

public class RulesController {
}
