package com.models;

public class Preparation {
}
