package com.example.seven_wonder;

import com.example.seven_wonder.models.Player;

import java.util.ArrayList;
import java.util.List;

public class Gameboard {

    List<Player> playerList = new ArrayList<>();

    // 2 joueurs


}
