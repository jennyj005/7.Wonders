package com.models;

public class ProgressCoins {
}
