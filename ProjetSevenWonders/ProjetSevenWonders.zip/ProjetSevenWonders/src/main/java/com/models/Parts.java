package com.models;

public class Parts
{

}
