package com.models;

public class ClashCoins {
}
